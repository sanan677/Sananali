# Freak
## This Tool is New Updated Tool
 ## For Facebook Cloning.
 ## This Tool Doesn't Require Any Login.
 ## Login Free Facebook Hacking.
 
 # Commands For This Tool
 ## apt update && apt upgrade
 ## apt install python python2
 ## apt install git
 ## pip2 install requests mechanize
 ## git clone https:github.com/Freaked-Dude/Freak
 ## cd Freak
 ## python2 Freak
